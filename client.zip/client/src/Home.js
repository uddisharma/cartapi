import logo from "./logo.svg";
import "./App.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
function Home() {
  const [data, setData] = useState([]);
  const [quantity, setQuanity] = useState(1);
  const [loading, setLoading] = useState(false);
  const userId = "6495d42dd79201287934cb84";
  useEffect(() => {
    axios
      .get("http://localhost:8000/products")
      .then((res) => {
        // console.log(res.data);
        setData(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const handleaddtocart = (id) => {
    setLoading(true);
    axios
      .post("http://localhost:8000/cart", {
        product: id,
        quantity,
        userId,
      })
      .then((res) => {
        console.log(res);
        setLoading(false);
        alert("added to cart");
      })
      .catch((err) => {
        console.log(err);
        alert("Something went wrong");
      });
  };
  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          width: "60%",
          margin: "auto",
        }}
      >
        <h1 style={{ textAlign: "center" }}>Products</h1>
        <Link to="/cart">
          <h1 style={{ textAlign: "right", cursor: "pointer" }}>Cart</h1>
        </Link>
        <Link to="/orders">
          <h1 style={{ textAlign: "right", cursor: "pointer" }}>Orders</h1>
        </Link>
      </div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "20px",
          height: "250px",
        }}
      >
        {data &&
          data.map((e) => (
            <div
              style={{
                border: "2px solid gray",
                margin: "20px",
                padding: "20px",
              }}
            >
              <img
                style={{ width: "100%" }}
                src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZHVjdHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60"
              />
              <h1 style={{ textAlign: "center" }}>Name : {e.name}</h1>
              <h3 style={{ textAlign: "center" }}>Price : {e.price}</h3>
              <div
                style={{
                  display: "block",
                  margin: "auto",
                  width: "100%",
                  textAlign: "center",
                }}
              >
                <button
                  disabled={quantity == 1}
                  onClick={() => {
                    setQuanity(quantity - 1);
                  }}
                >
                  -
                </button>
                <button>{quantity}</button>
                <button
                  onClick={() => {
                    setQuanity(quantity + 1);
                  }}
                >
                  +
                </button>
              </div>
              <br />
              <button
                disabled={loading}
                onClick={() => {
                  handleaddtocart(e._id);
                }}
                style={{
                  textAlign: "center",
                  display: "block",
                  margin: "auto",
                  height: "50px",
                  width: "100px",
                }}
              >
                add to cart
              </button>
            </div>
          ))}
      </div>
    </>
  );
}

export default Home;
