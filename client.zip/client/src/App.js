import React from 'react'
import { Route,Routes } from 'react-router-dom'
import Home from './Home'
import Cart from './Cart'
import Orders from './Orders'

const App = () => {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='/orders' element={<Orders/>}/>

      </Routes>
    </div>
  )
}

export default App