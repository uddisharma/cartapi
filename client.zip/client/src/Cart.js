import axios from "axios";
import React, { useEffect, useState } from "react";

const Cart = () => {
  const userId = "6495d42dd79201287934cb84";
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  let order = [];

  const cart = () => {
    axios
      .get(`http://localhost:8000/cart/${userId}`)
      .then((res) => {
        // console.log(res.data);
        setData(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    cart();
  }, []);
  const decreaseQuantity = (id) => {
    setLoading(true);
    axios
      .put(`http://localhost:8000/cart/${id}/decrease`)
      .then((res) => {
        setLoading(false);
        cart();
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const increaseQuantity = (id) => {
    setLoading(true);
    axios
      .put(`http://localhost:8000/cart/${id}/increase`)
      .then((res) => {
        console.log(res);
        setLoading(false);
        cart();
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const deletecart = (id) => {
    axios
      .delete(`http://localhost:8000/cart/${id}/delete`)
      .then((res) => {
        cart();
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const handleorder = () => {
    for (var i = 0; i < data.length; i++) {
      const singleorder = {
        product: data[i].product._id,
        quantity: data[i].quantity,
      };
      order.push(singleorder);
    }
    const orders = {
      product: order,
      userId,
    };
    // console.log(orders);
    axios
      .post(`http://localhost:8000/order`, orders)
      .then((res) => {
        console.log(res);
        alert("order placed successfully");
      })
      .catch((err) => console.log(err));
  };
  return (
    <div
      style={{
        textAlign: "center",
        display: "block",
        margin: "auto",
        height: "100%",
        width: "100%",
      }}
    >
      <h1>Cart List</h1>
      <table
        style={{
          textAlign: "center",
          display: "block",
          margin: "auto",
          height: "100%",
          width: "100%",
        }}
      >
        <tr>
          <th>Product Name</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Actions</th>
        </tr>

        {data &&
          data.map((e) => (
            <tr>
              <td>{e.product.name}</td>
              <td>{e.product.price}</td>
              <td>{e.quantity}</td>
              <td>
                <div
                  style={{
                    display: "block",
                    margin: "auto",
                    width: "100%",
                    textAlign: "center",
                  }}
                >
                  <button
                    disabled={loading}
                    onClick={() => {
                      decreaseQuantity(e._id);
                    }}
                  >
                    -
                  </button>
                  <button
                    disabled={loading}
                    onClick={() => {
                      increaseQuantity(e._id);
                    }}
                  >
                    +
                  </button>
                  <button
                    disabled={loading}
                    onClick={() => {
                      deletecart(e._id);
                    }}
                  >
                    delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
      </table>
      <button
        disabled={loading}
        onClick={() => {
          handleorder();
        }}
        style={{
          textAlign: "center",
          display: "block",
          margin: "auto",
          height: "50px",
          width: "100px",
        }}
      >
        Place Order
      </button>
    </div>
  );
};

export default Cart;
