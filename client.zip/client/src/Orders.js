import React, { useEffect, useState } from "react";
import axios from "axios";
const Orders = () => {
  const userId = "6495d42dd79201287934cb84";
  const [data, setData] = useState([]);
  useEffect(() => {
    axios
      .get(`http://localhost:8000/orders/${userId}`)
      .then((res) => {
        console.log(res);
        setData(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <div>
      <h1>Orders</h1>
      <table
        style={{
          textAlign: "center",
          display: "block",
          margin: "auto",
          height: "100%",
          width: "100%",
        }}
      >
        <tr>
          <th>Product Name</th>
          <th>Price</th>
          <th>Quantity</th>
          
        </tr>
        {data &&
          data.map((e) => (
            e.product.map((p)=>(
                <tr>
                <td>{p.product.name}</td>
                <td>{p.product.price}</td>
                <td>{p.quantity}</td>
              </tr>
            ))
           
          ))}
      </table>
    </div>
  );
};

export default Orders;
